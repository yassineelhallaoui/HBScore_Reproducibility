# Reproducing the HBScore article results

This supplement contains the code that reproduces the reported tables and figures, the input records that code reads, the public dataset links and the practitioner survey data. Generated outputs are not included; the commands below recreate them.

HBScore has three core outputs: physical demand, operational friction and component capacity ratios. Raw stored bytes and byte throughput are external financial-reference quantities. Stored bytes also remain a recorded input to the fitted demand model and storage comparison.

## Contents

- `reproduction_code/`: replay, checking, refitting, sensitivity and figure code.
- `Datasets.html`: publisher and recorded retrieval links for the eighteen-source benchmark.
- `Survey_and_Sensitivity_Data.html`: index of the survey exports, questionnaire wording, sector statistics, the 51 sensitivity profiles and the post-test checkpoints.
- `supporting_measurements/survey_exports/`: the three original survey exports, with 26 finance, 20 healthcare and 35 industrial/IoT responses.
- `supporting_measurements/`: questionnaire wording, sector sufficient statistics, the 51 frozen sensitivity profiles, sensitivity weights, original checkpoints and the historical-price assumptions for the worked example.
- `research/outputs/`: the frozen benchmark observations, predictions, model metrics and hardware capacity record read by the replay.
- `research/config/`, `research/code/routeb/` and `research/environment/`: the model lock and validation settings, the original validation module and the historical environment record used by the exact refit.
- `requirements-replay-tested.txt` and `SHA256SUMS.json`: the tested replay environment and a checksum for every supplied file.

The raw source archives for the benchmark are not embedded. Source URLs can change, and the local Synthea generation record is incomplete. The frozen records support offline replay of the reported calculations; exact public reconstruction of every raw source input is not claimed. The sensitivity analysis starts from the supplied profiles rather than a new extraction of the original raw datasets.

## Offline replay

From this directory, with `requirements-replay-tested.txt` (tested with Python 3.9):

```bash
python reproduction_code/verify_package.py
python reproduction_code/test_decision_contract.py
python reproduction_code/test_business_metrics.py
python reproduction_code/reproduce.py --out reproduced
```

The entry point recomputes:

- Byte rates and workload quartiles for Table 4 and Figure 2.
- The recorded CDC pair, all three outputs and the financial scenario for Table 5.
- Development-model statistics checked against original predictions for Table 6.
- The three held-out resource statistics for Table 7, the nine family results and Figure 3.
- Survey alpha and both concordance calculations directly from the included exports, checked against the stored sufficient statistics, for Tables 8 and 9 and Figure 4.
- The recorded Monte Carlo and post-test summaries for Table 10 and Figures 5 and 6.
- The three-output architecture diagram in Figure 1.

Tables 1 to 3 describe literature, output definitions and financial quantities. They are specifications rather than numerical experiments. The main command also writes retrospective context summaries under `reproduced/research_context/`.

## Resimulate the sensitivity audit

```bash
python reproduction_code/reproduce.py --out reproduced --resimulate
```

This regenerates the 100,000-draw weight-only run and all twelve grid settings, checking the 2,000-, 10,000- and 100,000-draw checkpoints against the completed records. Seed 42, fixed profile order, four-decimal calculation values and stable tie ordering are retained. These are exploratory sensitivity results, separate from the final three-output definition and the resource-model validation.

## Refit the resource models

Exact refitting uses the historical environment recorded in `research/environment/requirements-lock.txt`, including NumPy 2.5.1 and scikit-learn 1.9.0; the recorded check used Python 3.13. Grouped-fold allocation can change across library versions and alter residual calibration, so the script requires those versions.

```bash
python reproduction_code/refit_resource_models.py --out reproduced/refit
```

The script fits the locked physical-demand specification for processing time, p95 latency and memory on 4,320 conditions from fourteen development families. It evaluates the three fixed holdout families, checks the resulting statistics against the frozen values and writes the refitted predictions. This reconstructs completed evidence; it is not a new independent holdout.

## Interpretation and integrity

The survey contains one administration, not a multi-round Delphi or a test-retest study. The original unadjusted Kendall W values are retained beside the tie-corrected values. Alpha is reported by scale and sector. The post-tests are computational sensitivity checks.

The worked example uses two real controlled workload conditions. Its financial amounts use explicitly supplied scenario rates and allocation assumptions, rather than invoices or achieved savings.

`verify_package.py` checks every supplied file against `SHA256SUMS.json` before analysis. Direct author identifiers have been removed from textual records; numerical responses and measurements are unchanged.

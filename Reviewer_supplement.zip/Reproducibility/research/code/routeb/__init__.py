"""HB-Score Route B benchmark package."""

__version__ = "0.1.0"


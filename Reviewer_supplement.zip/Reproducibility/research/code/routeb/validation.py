from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


@dataclass(frozen=True)
class ModelSpec:
    numeric: tuple[str, ...]
    categorical: tuple[str, ...] = ("workload",)
    log_numeric: tuple[str, ...] = ()
    workload_interactions: tuple[str, ...] = ()


MODEL_SPECS = {
    "bytes_only": ModelSpec(("storage_bytes",)),
    "shape_baseline": ModelSpec(("storage_bytes", "rows", "columns")),
    "physical_demand": ModelSpec((
        "storage_bytes", "ingest_events_per_second", "compute_cells",
        "io_amplification", "network_egress_bytes", "concurrency_workers",
    )),
    "routeb_additive": ModelSpec(("demand_index", "friction_index")),
    "routeb_no_graph": ModelSpec((
        "demand_index", "friction_no_graph", "interaction_no_graph",
    )),
    "routeb_full": ModelSpec(("demand_index", "friction_index", "interaction")),
    "all_components": ModelSpec((
        "storage_bytes", "ingest_events_per_second", "compute_cells",
        "io_amplification", "network_egress_bytes", "concurrency_workers",
        "variety_count", "quality_debt_rate", "graph_edges_per_node",
        "ambiguity_rate",
    )),
}

WORKLOAD_LEVELS = (
    "ingest_parse", "scan", "filter", "aggregate", "join", "export",
    "quality_check", "schema_map",
)

EXTENSION_MODEL_SPECS = {
    "bytes_only_extension": ModelSpec(
        (), log_numeric=("storage_bytes",),
    ),
    "shape_baseline_extension": ModelSpec(
        (), log_numeric=("storage_bytes", "rows", "columns"),
    ),
    "physical_demand_extension": ModelSpec(
        ("io_amplification",),
        log_numeric=(
            "storage_bytes", "ingest_events_per_second", "compute_cells",
            "network_egress_bytes", "concurrency_workers",
        ),
        workload_interactions=(
            "storage_bytes", "compute_cells", "concurrency_workers",
        ),
    ),
    "shape_graph_extension": ModelSpec(
        ("graph_density", "join_depth"),
        log_numeric=(
            "storage_bytes", "rows", "columns", "relationship_count",
            "graph_nodes", "graph_edges", "mean_dimension_cardinality",
            "max_dimension_cardinality", "mean_relationship_fanout",
        ),
    ),
    "components_additive_extension": ModelSpec(
        ("io_amplification", "variety_count", "quality_debt_rate",
         "ambiguity_rate", "graph_density", "join_depth"),
        log_numeric=(
            "storage_bytes", "ingest_events_per_second", "compute_cells",
            "network_egress_bytes", "concurrency_workers",
            "relationship_count", "mean_relationship_fanout",
        ),
        workload_interactions=(
            "storage_bytes", "compute_cells", "concurrency_workers",
        ),
    ),
    "components_interaction_extension": ModelSpec(
        ("io_amplification", "variety_count", "quality_debt_rate",
         "ambiguity_rate", "graph_density", "join_depth",
         "interaction_rows_quality", "interaction_compute_variety",
         "interaction_rows_fanout", "interaction_storage_concurrency"),
        log_numeric=(
            "storage_bytes", "ingest_events_per_second", "compute_cells",
            "network_egress_bytes", "concurrency_workers",
            "relationship_count", "mean_relationship_fanout",
        ),
        workload_interactions=(
            "storage_bytes", "compute_cells", "concurrency_workers",
        ),
    ),
}


def assert_group_disjoint(train_groups: np.ndarray, test_groups: np.ndarray) -> None:
    overlap = set(train_groups) & set(test_groups)
    if overlap:
        raise AssertionError(f"Dataset family leakage: {sorted(overlap)}")


def _log_name(column: str) -> str:
    return f"log1p__{column}"


def _interaction_name(column: str, workload: str) -> str:
    return f"workload_interaction__{column}__{workload}"


def _numeric_columns(spec: ModelSpec) -> list[str]:
    columns = list(spec.numeric) + [_log_name(column) for column in spec.log_numeric]
    columns.extend(
        _interaction_name(column, workload)
        for column in spec.workload_interactions
        for workload in WORKLOAD_LEVELS
    )
    return columns


def _prepare_model_frame(frame: pd.DataFrame, spec: ModelSpec) -> pd.DataFrame:
    prepared = frame.copy()
    for column in spec.log_numeric:
        values = pd.to_numeric(prepared[column], errors="coerce").clip(lower=0)
        prepared[_log_name(column)] = np.log1p(values)
    for column in spec.workload_interactions:
        if column in spec.log_numeric:
            values = prepared[_log_name(column)]
        else:
            values = pd.to_numeric(prepared[column], errors="coerce")
        for workload in WORKLOAD_LEVELS:
            prepared[_interaction_name(column, workload)] = (
                values * prepared["workload"].eq(workload).astype(float)
            )
    return prepared


def _pipeline(spec: ModelSpec, alpha: float) -> Pipeline:
    numeric = Pipeline([
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
    ])
    categorical = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    transform = ColumnTransformer([
        ("numeric", numeric, _numeric_columns(spec)),
        ("categorical", categorical, list(spec.categorical)),
    ])
    return Pipeline([("transform", transform), ("model", Ridge(alpha=alpha))])


def _select_alpha(frame: pd.DataFrame, target: str, groups: np.ndarray,
                  spec: ModelSpec, alphas: list[float], inner_folds: int) -> float:
    unique_groups = np.unique(groups)
    folds = min(inner_folds, len(unique_groups))
    if folds < 2:
        return 1.0
    splitter = GroupKFold(n_splits=folds)
    y = np.log1p(frame[target].to_numpy(dtype=float))
    best_alpha, best_error = alphas[0], float("inf")
    for alpha in alphas:
        errors = []
        for train_index, test_index in splitter.split(frame, y, groups):
            assert_group_disjoint(groups[train_index], groups[test_index])
            model = _pipeline(spec, alpha)
            model.fit(_prepare_model_frame(frame.iloc[train_index], spec), y[train_index])
            prediction = model.predict(_prepare_model_frame(frame.iloc[test_index], spec))
            errors.append(mean_absolute_error(y[test_index], prediction))
        error = float(np.mean(errors))
        if error < best_error:
            best_alpha, best_error = alpha, error
    return best_alpha


def _grouped_residual_quantile(frame: pd.DataFrame, target: str,
                               groups: np.ndarray, spec: ModelSpec,
                               alpha: float, inner_folds: int,
                               coverage: float) -> float:
    unique_groups = np.unique(groups)
    folds = min(inner_folds, len(unique_groups))
    if folds < 2:
        return 0.0
    splitter = GroupKFold(n_splits=folds)
    y = np.log1p(frame[target].to_numpy(dtype=float))
    residuals = []
    for train_index, test_index in splitter.split(frame, y, groups):
        assert_group_disjoint(groups[train_index], groups[test_index])
        model = _pipeline(spec, alpha)
        model.fit(_prepare_model_frame(frame.iloc[train_index], spec), y[train_index])
        prediction = model.predict(_prepare_model_frame(frame.iloc[test_index], spec))
        residuals.extend(np.abs(y[test_index] - prediction))
    return float(np.quantile(residuals, coverage, method="higher"))


def _finite_sample_quantile(values: list[float], coverage: float) -> float:
    if not values:
        return 0.0
    level = min(1.0, np.ceil((len(values) + 1) * coverage) / len(values))
    return float(np.quantile(values, level, method="higher"))


def _mondrian_residual_quantiles(frame: pd.DataFrame, target: str,
                                 groups: np.ndarray, spec: ModelSpec,
                                 alpha: float, inner_folds: int,
                                 coverage: float,
                                 category_column: str) -> tuple[dict[str, float], float]:
    """Calibrate finite-sample residual widths within registered workloads."""
    folds = min(inner_folds, len(np.unique(groups)))
    if folds < 2:
        return {}, 0.0
    splitter = GroupKFold(n_splits=folds)
    y = np.log1p(frame[target].to_numpy(dtype=float))
    residuals: dict[str, list[float]] = {}
    all_residuals: list[float] = []
    for train_index, test_index in splitter.split(frame, y, groups):
        assert_group_disjoint(groups[train_index], groups[test_index])
        model = _pipeline(spec, alpha)
        model.fit(
            _prepare_model_frame(frame.iloc[train_index], spec), y[train_index]
        )
        prediction = model.predict(
            _prepare_model_frame(frame.iloc[test_index], spec)
        )
        errors = np.abs(y[test_index] - prediction)
        categories = frame.iloc[test_index][category_column].astype(str).to_numpy()
        for category, error in zip(categories, errors):
            residuals.setdefault(category, []).append(float(error))
            all_residuals.append(float(error))
    global_quantile = _finite_sample_quantile(all_residuals, coverage)
    return {
        category: _finite_sample_quantile(values, coverage)
        for category, values in residuals.items()
    }, global_quantile


def grouped_nested_predictions(frame: pd.DataFrame, target: str,
                               group_column: str = "family",
                               model_specs: dict[str, ModelSpec] | None = None,
                               alphas: list[float] | None = None,
                               inner_folds: int = 4,
                               interval_coverage: float = 0.90,
                               interval_group_column: str | None = None) -> pd.DataFrame:
    specs = model_specs or MODEL_SPECS
    alphas = alphas or [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]
    groups = frame[group_column].astype(str).to_numpy()
    if len(np.unique(groups)) < 3:
        raise ValueError("At least three dataset families are needed")
    y = frame[target].to_numpy(dtype=float)
    splitter = LeaveOneGroupOut()
    rows = []
    for fold, (train_index, test_index) in enumerate(splitter.split(frame, y, groups)):
        assert_group_disjoint(groups[train_index], groups[test_index])
        train = frame.iloc[train_index]
        alpha_groups = groups[train_index]
        for model_name, spec in specs.items():
            alpha = _select_alpha(
                train, target, alpha_groups, spec, alphas, inner_folds
            )
            if interval_group_column:
                residual_quantiles, residual_fallback = _mondrian_residual_quantiles(
                    train, target, alpha_groups, spec, alpha, inner_folds,
                    interval_coverage, interval_group_column,
                )
            else:
                residual_fallback = _grouped_residual_quantile(
                    train, target, alpha_groups, spec, alpha, inner_folds,
                    interval_coverage,
                )
                residual_quantiles = {}
            model = _pipeline(spec, alpha)
            model.fit(_prepare_model_frame(train, spec), np.log1p(y[train_index]))
            prediction_log = model.predict(
                _prepare_model_frame(frame.iloc[test_index], spec)
            )
            predictions = np.maximum(0.0, np.expm1(prediction_log))
            if interval_group_column:
                categories = frame.iloc[test_index][interval_group_column].astype(str)
                widths = np.array([
                    residual_quantiles.get(category, residual_fallback)
                    for category in categories
                ])
            else:
                widths = np.full(len(test_index), residual_fallback)
            lower = np.maximum(0.0, np.expm1(prediction_log - widths))
            upper = np.maximum(0.0, np.expm1(prediction_log + widths))
            for local_index, prediction, low, high in zip(
                test_index, predictions, lower, upper
            ):
                rows.append({
                    "row_index": int(local_index),
                    "fold": fold,
                    "held_out_family": groups[local_index],
                    "model": model_name,
                    "target": target,
                    "observed": float(y[local_index]),
                    "predicted": float(prediction),
                    "absolute_error": float(abs(y[local_index] - prediction)),
                    "interval_lower": float(low),
                    "interval_upper": float(high),
                    "interval_coverage_nominal": interval_coverage,
                    "interval_contains_observed": bool(low <= y[local_index] <= high),
                    "alpha": alpha,
                    "evaluation": "development_cross_validation",
                })
    return pd.DataFrame(rows)


def grouped_holdout_predictions(train: pd.DataFrame, holdout: pd.DataFrame,
                                target: str, group_column: str = "family",
                                model_specs: dict[str, ModelSpec] | None = None,
                                alphas: list[float] | None = None,
                                inner_folds: int = 4,
                                interval_coverage: float = 0.90,
                                interval_group_column: str | None = None) -> pd.DataFrame:
    """Fit on development families and open a named holdout once."""
    specs = model_specs or MODEL_SPECS
    alphas = alphas or [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]
    train_groups = train[group_column].astype(str).to_numpy()
    holdout_groups = holdout[group_column].astype(str).to_numpy()
    assert_group_disjoint(train_groups, holdout_groups)
    if len(np.unique(train_groups)) < 3:
        raise ValueError("At least three development families are needed")
    y_train = train[target].to_numpy(dtype=float)
    y_holdout = holdout[target].to_numpy(dtype=float)
    rows = []
    for model_name, spec in specs.items():
        alpha = _select_alpha(
            train, target, train_groups, spec, alphas, inner_folds
        )
        if interval_group_column:
            residual_quantiles, residual_fallback = _mondrian_residual_quantiles(
                train, target, train_groups, spec, alpha, inner_folds,
                interval_coverage, interval_group_column,
            )
        else:
            residual_fallback = _grouped_residual_quantile(
                train, target, train_groups, spec, alpha, inner_folds,
                interval_coverage,
            )
            residual_quantiles = {}
        model = _pipeline(spec, alpha)
        model.fit(_prepare_model_frame(train, spec), np.log1p(y_train))
        prediction_log = model.predict(_prepare_model_frame(holdout, spec))
        predicted = np.maximum(0.0, np.expm1(prediction_log))
        if interval_group_column:
            widths = np.array([
                residual_quantiles.get(category, residual_fallback)
                for category in holdout[interval_group_column].astype(str)
            ])
        else:
            widths = np.full(len(holdout), residual_fallback)
        lower = np.maximum(0.0, np.expm1(prediction_log - widths))
        upper = np.maximum(0.0, np.expm1(prediction_log + widths))
        for position, (index, prediction, low, high) in enumerate(zip(
            holdout.index, predicted, lower, upper
        )):
            observed = y_holdout[position]
            rows.append({
                "row_index": int(index),
                "fold": -1,
                "held_out_family": holdout_groups[position],
                "model": model_name,
                "target": target,
                "observed": float(observed),
                "predicted": float(prediction),
                "absolute_error": float(abs(observed - prediction)),
                "interval_lower": float(low),
                "interval_upper": float(high),
                "interval_coverage_nominal": interval_coverage,
                "interval_contains_observed": bool(low <= observed <= high),
                "alpha": alpha,
                "evaluation": "final_holdout",
            })
    return pd.DataFrame(rows)


def prediction_metrics(predictions: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (target, model), group in predictions.groupby(["target", "model"]):
        observed = group["observed"].to_numpy()
        predicted = group["predicted"].to_numpy()
        observed_log = np.log1p(observed)
        predicted_log = np.log1p(predicted)
        correlation = spearmanr(observed, predicted).statistic
        rows.append({
            "target": target,
            "model": model,
            "n": len(group),
            "families": group["held_out_family"].nunique(),
            "mae": mean_absolute_error(observed, predicted),
            "rmse": mean_squared_error(observed, predicted) ** 0.5,
            "r2": r2_score(observed, predicted),
            "log_mae": mean_absolute_error(observed_log, predicted_log),
            "log_rmse": mean_squared_error(observed_log, predicted_log) ** 0.5,
            "log_r2": r2_score(observed_log, predicted_log),
            "spearman": float(correlation),
            "interval_coverage": float(group["interval_contains_observed"].mean()),
            "median_interval_width": float(
                (group["interval_upper"] - group["interval_lower"]).median()
            ),
        })
    return pd.DataFrame(rows)


def family_bootstrap_improvement(predictions: pd.DataFrame,
                                 reference: str = "bytes_only",
                                 candidate: str = "routeb_full",
                                 draws: int = 2000,
                                 seed: int = 20260829) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    for target, target_rows in predictions.groupby("target"):
        pivot = target_rows.pivot_table(
            index=["row_index", "held_out_family"], columns="model",
            values="absolute_error", aggfunc="first",
        ).dropna(subset=[reference, candidate])
        families = pivot.index.get_level_values("held_out_family").unique().to_numpy()
        observed = float((pivot[reference] - pivot[candidate]).mean())
        samples = []
        for _ in range(draws):
            selected = rng.choice(families, size=len(families), replace=True)
            values = []
            for family in selected:
                part = pivot.xs(family, level="held_out_family")
                values.extend((part[reference] - part[candidate]).tolist())
            samples.append(float(np.mean(values)))
        rows.append({
            "target": target,
            "reference": reference,
            "candidate": candidate,
            "mae_improvement": observed,
            "ci_low": float(np.percentile(samples, 2.5)),
            "ci_high": float(np.percentile(samples, 97.5)),
            "families": len(families),
            "bootstrap_draws": draws,
        })
    return pd.DataFrame(rows)


def validate_all(frame: pd.DataFrame, targets: list[str],
                 model_specs: dict[str, ModelSpec] | None = None,
                 interval_group_column: str | None = None
                 ) -> tuple[pd.DataFrame, pd.DataFrame]:
    predictions = pd.concat(
        [grouped_nested_predictions(
            frame, target, model_specs=model_specs,
            interval_group_column=interval_group_column,
        ) for target in targets],
        ignore_index=True,
    )
    return predictions, prediction_metrics(predictions)

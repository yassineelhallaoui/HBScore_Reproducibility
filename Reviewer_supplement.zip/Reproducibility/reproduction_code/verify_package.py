"""Check packaged evidence before analysis; no network access or mutation."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
records = json.loads((root/"SHA256SUMS.json").read_text())
failures = [name for name, expected in records.items()
            if not (root/name).is_file()
            or hashlib.sha256((root/name).read_bytes()).hexdigest() != expected]
if failures:
    raise SystemExit("Evidence verification failed: " + ", ".join(failures))
print(f"Verified {len(records)} packaged files")

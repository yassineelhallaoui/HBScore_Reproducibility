"""Checks for external throughput and unit-cost calculations."""
import unittest
from business_metrics import external_metrics
from business_cases import cases


class BusinessMetricTests(unittest.TestCase):
    def setUp(self):
        self.scope={"service_id":"s","unit":"accepted request","start":"2026-01-01T00:00:00Z","end":"2026-01-01T01:00:00Z"}
        self.cost_scope={**self.scope,"allocation_rule":"service allocation","cost_basis":"observed service cost"}

    def test_rate_and_unit_cost(self):
        x=external_metrics(3600,self.scope,180,"USD",self.cost_scope)
        self.assertEqual(x["throughput_units_per_second"],1)
        self.assertEqual(x["cost_per_unit"],.05)

    def test_missing_cost_does_not_become_free(self):
        x=external_metrics(3600,self.scope)
        self.assertIsNone(x["cost_per_unit"])
        self.assertEqual(x["financial_status"],"cost_unavailable")

    def test_mismatched_windows_are_rejected(self):
        with self.assertRaises(ValueError):
            external_metrics(1,self.scope,1,"USD",{**self.cost_scope,"end":"2026-01-02T01:00:00Z"})

    def test_zero_output_has_no_unit_cost(self):
        x=external_metrics(0,self.scope,180,"USD",self.cost_scope)
        self.assertIsNone(x["cost_per_unit"])

    def test_invalid_inputs(self):
        for units,cost in [(-1,1),(1,-1),(float("nan"),1)]:
            with self.assertRaises(ValueError):external_metrics(units,self.scope,cost,"USD",self.cost_scope)

    def test_zero_cost_is_explicit(self):
        x=external_metrics(100,self.scope,0,"USD",self.cost_scope)
        self.assertEqual(x["cost_per_unit"],0)
        self.assertIsNone(x["completed_units_per_currency"])

    def test_only_three_core_outputs(self):
        for case in cases():
            self.assertEqual(set(case["core_outputs"]),{"physical_demand","operational_friction","component_capacity_ratios"})
            self.assertEqual(case["external_business_metrics"]["basis"],"scenario")

    def test_byte_unit_is_preserved(self):
        scope={**self.scope,"unit":"byte"}
        cost_scope={**self.cost_scope,**scope}
        x=external_metrics(3_600_000_000,scope,180,"USD",cost_scope)
        self.assertEqual(x["scope"]["unit"],"byte")
        self.assertEqual(x["throughput_units_per_second"],1_000_000)
        self.assertAlmostEqual(x["cost_per_unit"]*1e9,50)

    def test_more_throughput_is_not_automatically_cheaper(self):
        baseline,upgrade,_=cases()
        a,b=baseline["external_business_metrics"],upgrade["external_business_metrics"]
        self.assertGreater(b["throughput_units_per_hour"],a["throughput_units_per_hour"])
        self.assertGreater(b["cost_per_unit"],a["cost_per_unit"])


if __name__=="__main__":unittest.main()

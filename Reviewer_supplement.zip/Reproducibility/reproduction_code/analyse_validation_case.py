"""Reproduce model comparisons, family results and a recorded workload example."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator,FuncFormatter,NullFormatter
import numpy as np
import pandas as pd

from decision_contract import decision_card

TARGETS={'wall_time_seconds':'Processing time','p95_latency_seconds':'p95 latency','peak_rss_bytes':'Peak resident memory'}
MODELS=['bytes_only','shape_baseline','physical_demand','all_components']


def main():
    root=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser()
    p.add_argument('--package',type=Path,default=root);p.add_argument('--out',type=Path,default=root/'reproduced');p.add_argument('--figures',type=Path)
    args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True);figures=args.figures or args.out/'Figures';figures.mkdir(parents=True,exist_ok=True)
    frozen=args.package/'research/outputs/final_frozen';frame=pd.read_csv(frozen/'benchmark_trials.csv')
    metrics=pd.read_csv(frozen/'model_metrics.csv');comparison=metrics.loc[metrics.target.isin(TARGETS)&metrics.model.isin(MODELS)].copy()
    assert len(comparison)==12 and comparison.n.eq(4320).all()
    development=pd.read_csv(frozen/'predictions.csv')
    for _,metric in comparison.iterrows():
        rows=development.loc[development.model.eq(metric.model)&development.target.eq(metric.target)]
        assert len(rows)==4320
        observed=rows.observed.to_numpy();predicted=rows.predicted.to_numpy()
        a=np.log1p(observed);b=np.log1p(predicted)
        actual=[np.abs(observed-predicted).mean(),1-np.square(a-b).sum()/np.square(a-a.mean()).sum()]
        np.testing.assert_allclose(actual,[metric.mae,metric.log_r2],rtol=1e-10,atol=1e-8)
    comparison.to_csv(args.out/'model_comparison.csv',index=False)
    predictions=pd.read_csv(frozen/'final_holdout_predictions.csv');predictions=predictions.loc[predictions.target.isin(TARGETS)&predictions.model.eq('physical_demand')]
    families=[]
    for (target,family),group in predictions.groupby(['target','held_out_family']):
        observed=group.observed.to_numpy();predicted=group.predicted.to_numpy();a=np.log1p(observed);b=np.log1p(predicted)
        coverage=((observed>=group.interval_lower)&(observed<=group.interval_upper)).mean()
        families.append({'target':target,'family':family,'conditions':len(group),'log_r2':1-np.square(a-b).sum()/np.square(a-a.mean()).sum(),'interval_coverage':coverage})
    pd.DataFrame(families).to_csv(args.out/'holdout_family_results.csv',index=False)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
    fig,axes=plt.subplots(1,3,figsize=(7.4,3.5),constrained_layout=True)
    colors=['#347d79','#4a6fa5','#b9893c'];labels={'clinicaltrials_gov':'ClinicalTrials.gov','nasa_cmapss':'NASA C-MAPSS','sec_financial_statements':'SEC statements'}
    for ax,(target,label) in zip(axes,TARGETS.items()):
        subset=predictions.loc[predictions.target.eq(target)];scale=1e6 if target=='peak_rss_bytes' else 1
        for color,family in zip(colors,sorted(subset.held_out_family.unique())):
            rows=subset.loc[subset.held_out_family.eq(family)];ax.scatter(rows.observed/scale,rows.predicted/scale,s=9,alpha=.35,color=color,label=labels[family],rasterized=True)
        values=np.r_[subset.observed/scale,subset.predicted/scale];lo=values[values>0].min()*.9;hi=values.max()*1.1
        ax.plot([lo,hi],[lo,hi],color='#555',ls='--',lw=.8);ax.set(xscale='log',yscale='log',xlim=(lo,hi),ylim=(lo,hi),title=label,xlabel='Observed '+('MB' if scale>1 else 'seconds'),ylabel='Predicted '+('MB' if scale>1 else 'seconds'));ax.grid(alpha=.12)
        ax.xaxis.set_minor_formatter(NullFormatter());ax.yaxis.set_minor_formatter(NullFormatter())
        if scale>1:
            ax.xaxis.set_major_locator(FixedLocator([200,500,1000]));ax.yaxis.set_major_locator(FixedLocator([200,500,1000]))
            ax.xaxis.set_major_formatter(FuncFormatter(lambda value,_:f'{value:g}'));ax.yaxis.set_major_formatter(FuncFormatter(lambda value,_:f'{value:g}'))
    axes[0].legend(fontsize=7,loc='upper left')
    for ext in ['png','pdf']:fig.savefig(figures/('Figure_3_holdout_resource_predictions.'+ext),dpi=600,bbox_inches='tight',facecolor='white')
    plt.close(fig)
    calibration=json.loads((args.package/'research/outputs/hardware_capacity.json').read_text())['capacity']
    prices=json.loads((args.package/'supporting_measurements/worked_example_prices.json').read_text())
    keys={'storage_bytes':'bytes','ingest_events_per_second':'events/second','compute_cells':'cells/window','concurrency_workers':'workers'}
    cases=[]
    for variant,label in [('trial_003','Before: recorded 4x volume'),('trial_001','After: recorded 1x volume')]:
        selected=frame.loc[frame.source_id.eq('cdc_chronic_disease_indicators')&frame.workload.eq('scan')&frame.variant_id.eq(variant)]
        assert len(selected)==1;row=selected.iloc[0];demand={k:{'value':float(row[k]),'unit':u} for k,u in keys.items()};capacity={k:{'value':calibration[k],'unit':u} for k,u in keys.items()}
        card=decision_card(demand,capacity,list(keys)+['memory','io','network'])
        seconds=float(row.wall_time_seconds);hour=seconds/3600;gb=float(row.bytes_read)/1e9
        cpu=prices['prices']['compute_usd_vcpu_hour']*prices['allocated_vcpu_count']*hour
        memory=prices['prices']['memory_usd_gb_hour']*float(row.peak_rss_bytes)/1e9*hour
        storage=prices['prices']['object_storage_usd_gb_month']*float(row.storage_bytes)/1e9*hour/prices['hours_month']
        case={'case':label,'basis':'Measured controlled workload pair; financial figures are a separate pricing scenario','source_id':row.source_id,'variant_id':variant,'workload':row.workload,
              'core_outputs':{'physical_demand':{k:float(row[k]) for k in ['ingest_events_per_second','compute_cells','io_amplification','network_egress_bytes','concurrency_workers']},
                              'operational_friction':{k:float(row[k]) for k in ['variety_count','quality_debt_rate','graph_edges_per_node','ambiguity_rate']},'component_capacity_ratios':card},
              'external_record':{'raw_storage_bytes':float(row.storage_bytes),'processed_bytes':float(row.bytes_read),'elapsed_seconds':seconds,'logical_bytes_per_second':float(row.bytes_read)/seconds},
              'observed_resource_outcomes':{'peak_rss_bytes':int(row.peak_rss_bytes),'processing_seconds':seconds},
              'financial_scenario':{'currency':'USD','window_seconds':seconds,'cpu_cost':cpu,'memory_cost':memory,'storage_cost':storage,'allocated_cost':cpu+memory+storage,'cost_per_processed_gb':(cpu+memory+storage)/gb,'actual_provider_bill':False}}
        cases.append(case)
    before,after=cases
    assert before['core_outputs']['operational_friction']==after['core_outputs']['operational_friction']
    assert before['core_outputs']['component_capacity_ratios']['coverage']==4/7
    assert after['core_outputs']['component_capacity_ratios']['status']=='incomplete'
    (args.out/'worked_assessment.json').write_text(json.dumps({'selection':'Fixed CDC scan pair trial_003 and trial_001; not selected for best financial result','cases':cases,'financial_prices':prices,'real_operator_or_financial_outcome_claimed':False},indent=2))
    print('Replayed four-model comparison, nine family results and the recorded worked pair.',flush=True)


if __name__=='__main__':main()

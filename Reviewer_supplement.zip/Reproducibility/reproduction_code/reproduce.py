"""Reproduce recorded byte throughput and retain the full research context."""
import argparse
from pathlib import Path
import subprocess
import sys


def main():
    root=Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser()
    p.add_argument('--package',type=Path,default=root)
    p.add_argument('--out',type=Path,default=Path('reproduced'))
    p.add_argument('--resimulate',action='store_true')
    args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    subprocess.run([sys.executable,str(root/'reproduction_code/validation_evidence.py'),'--package',str(args.package),
                    '--out',str(args.out)],check=True)
    subprocess.run([sys.executable,str(root/'reproduction_code/plot_solution_results.py'),'--package',str(args.package),
                    '--results',str(args.out),'--out',str(args.out/'Figures')],check=True)
    subprocess.run([sys.executable,str(root/'reproduction_code/analyse_validation_case.py'),'--package',str(args.package),'--out',str(args.out)],check=True)
    audit=[sys.executable,str(root/'reproduction_code/survey_sensitivity.py'),'--package',str(args.package),'--out',str(args.out)]
    if args.resimulate:audit.append('--rerun')
    subprocess.run(audit,check=True)
    subprocess.run([sys.executable,str(root/'reproduction_code/reproduce_research_context.py'),'--package',str(args.package),
                    '--out',str(args.out/'research_context')],check=True,capture_output=True,text=True)


if __name__=='__main__':main()

"""Recreate this article's retrospective summaries without fetching source data."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from decision_contract import decision_card, illustrative_cases


def main():
    parser = argparse.ArgumentParser()
    base = Path(__file__).resolve().parents[1]
    default_package = base if (base/"research").is_dir() else base/"Reproducibility"
    parser.add_argument("--package", type=Path, default=default_package)
    parser.add_argument("--out", type=Path, default=Path("reproduced"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    p = args.package
    frozen = p/"research/outputs/final_frozen"
    frame = pd.read_csv(frozen/"benchmark_trials.csv")
    hold = pd.read_csv(frozen/"final_holdout_locked_metrics.csv")
    for col in ["log_r2", "interval_coverage", "mae"]:
        hold[col] = pd.to_numeric(hold[col])
    hold.to_csv(args.out/"table_3_existing_validation.csv", index=False)
    # One scan record per estate.
    estates = frame[frame.workload.eq("scan")].copy()
    assert len(estates) == 648 and estates[["source_id", "variant_id"]].drop_duplicates().shape[0] == 648
    estates["score_band"] = estates.hb_demand.round(2)
    bands = estates.groupby("score_band").agg(
        estates=("storage_bytes", "size"), min_bytes=("storage_bytes", "min"),
        max_bytes=("storage_bytes", "max"), min_quality=("quality_debt_rate", "min"),
        max_quality=("quality_debt_rate", "max"),
        min_workers=("concurrency_workers", "min"), max_workers=("concurrency_workers", "max"))
    bands["byte_spread"] = bands.max_bytes / bands.min_bytes
    bands.to_csv(args.out/"score_bands_scan.csv")
    calibration = json.loads((p/"research/outputs/hardware_capacity.json").read_text())
    mapping = {"storage_bytes": "bytes", "ingest_events_per_second": "events/second",
               "compute_cells": "cells/window", "concurrency_workers": "workers"}
    capacity = {k: {"value": calibration["capacity"][k], "unit": u} for k,u in mapping.items()}
    cards = []
    for _, row in frame.iterrows():
        demand = {k: {"value": row[k], "unit": u} for k,u in mapping.items()}
        # Memory, I/O and network cannot be cleared by this four-component audit.
        card = decision_card(demand, capacity, list(mapping)+["memory", "io", "network"])
        cards.append({"family": row.family, "source_id": row.source_id,
                      "variant_id": row.variant_id, "workload": row.workload, **card})
    (args.out/"decision_cards.json").write_text(json.dumps(cards, indent=2))
    (args.out/"analytical_examples.json").write_text(json.dumps(illustrative_cases(), indent=2))
    summary = {"analysis_status": "retrospective_descriptive_2026-10-26",
               "benchmark_rows": len(frame), "sources": frame.source_id.nunique(),
               "families": frame.family.nunique(), "estates_scan_only": len(estates),
               "measured_repetitions": int(frame.n_measured_repetitions.sum()),
               "multi_estate_score_bands": int((bands.estates > 1).sum()),
               "maximum_within_band_byte_ratio": float(bands.byte_spread.max()),
               "capacity_coverage": 4/7,
               "card_statuses": pd.Series([c["status"] for c in cards]).value_counts().to_dict(),
               "benchmark_sha256": hashlib.sha256((frozen/"benchmark_trials.csv").read_bytes()).hexdigest()}
    (args.out/"summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

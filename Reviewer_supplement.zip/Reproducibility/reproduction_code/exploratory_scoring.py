"""Frozen exploratory calculations used only in the sensitivity audit."""
from __future__ import annotations
import math
import numpy as np

EPS=0.02

def _minmax(x: float, lo: float, hi: float, log: bool = False) -> float:
    if x is None:
        return EPS
    if log:
        x, lo, hi = (math.log10(max(v, 1e-9)) for v in (x, max(lo, 1e-9), hi))
    if hi <= lo:
        return EPS
    return float(np.clip((x - lo) / (hi - lo), EPS, 1.0))

def indicator_values(profile: dict, cfg: dict) -> dict:
    """Raw profile -> normalized indicator values in [0,1]."""
    fv, vu = profile["five_vs"], profile["vuca"]
    r = cfg["reference_ranges"]

    vel = fv["velocity"]
    events_per_day = vel.get("est_events_per_day") or 0.0
    med_s = vel.get("median_interval_s")
    if not events_per_day and med_s and med_s >= 1.0:
        # Subsecond ties do not establish a cadence.
        events_per_day = 86_400.0 / med_s

    q = (fv["veracity"].get("quality") or {}).get("quality_score")
    quality_issue = min(1.0, fv["veracity"]["missing_rate"] * 2
                        + fv["veracity"]["duplicate_rate"]
                        + fv["veracity"]["mixed_type_col_rate"])
    if q is not None:
        quality_issue = 1.0 - q
    value_evidence = (0.5 * bool(fv["value"]["has_target_labels"])
                      + 0.5 * bool(fv["value"]["has_metadata_docs"]))
    if fv["value"].get("expected_relevance") is not None:
        value_evidence = float(fv["value"]["expected_relevance"])

    return {
        "volume": _minmax(fv["volume"]["total_bytes"], **r["volume_bytes"], log=True),
        "velocity": _minmax(events_per_day, **r["events_per_day"], log=True),
        "variety": _minmax(fv["variety"]["dtype_entropy"]
                           + fv["variety"]["format_entropy"]
                           + fv["variety"]["n_modalities"] - 1,
                           **r["variety_index"]),
        "veracity": float(np.clip(1.0 - quality_issue, EPS, 1.0)),
        "value": float(np.clip(value_evidence, EPS, 1.0)),
        "volatility": _minmax(vu["volatility"]["growth_cv"], **r["growth_cv"]),
        "uncertainty": float(np.clip(vu["uncertainty"]["uncertainty_raw"] * 4, EPS, 1.0)),
        "complexity": _minmax(
            vu["complexity"]["density"] * 10
            + vu["complexity"]["centrality_concentration"]
            + math.log10(max(vu["complexity"]["n_nodes"], 1)) / 4,
            **r["complexity_index"]),
        "ambiguity": _minmax(vu["ambiguity"]["ambiguity_raw"], **r["ambiguity_raw"]),
    }

def geometric(values: dict, weights: dict) -> float:
    keys = [k for k in weights if k in values]
    w = np.array([weights[k] for k in keys], dtype=float)
    w = w / w.sum()
    v = np.array([max(values[k], EPS) for k in keys], dtype=float)
    return float(np.exp((w * np.log(v)).sum()))

def compute(profile: dict, weights_cfg: dict | None = None) -> dict:
    cfg = weights_cfg
    ind = indicator_values(profile, cfg)

    F = geometric(ind, cfg["inner_weights"]["five_vs"])
    U = geometric(ind, cfg["inner_weights"]["vuca"])
    outer = cfg["outer_weights"]
    a, b, g = outer["alpha"], outer["beta"], outer["gamma"]
    total = a + b + g
    a, b, g = a / total, b / total, g / total
    hb = a * F + b * U + g * F * U

    result = {
        "dataset": profile["dataset"],
        "industry": profile["industry"],
        "indicators": {k: round(v, 4) for k, v in ind.items()},
        "five_vs_composite": round(F, 4),
        "vuca_composite": round(U, 4),
        "outer_weights": {"alpha": a, "beta": b, "gamma": g},
        "hb_score": round(hb, 4),
        "hb_score_baseline": round((a / (a + b)) * F + (b / (a + b)) * U, 4),
        "specification": {
            "formula": f"HB = {a:.3f}*F + {b:.3f}*U + {g:.3f}*(F*U)",
            "baseline_formula": "HB_baseline = alpha'*F + beta'*U with gamma = 0",
            "within_composite": "weighted geometric mean: C = prod(v_i^(w_i/sum w)), floor 0.02",
            "F_definition": "Five Vs composite over " + ", ".join(cfg["inner_weights"]["five_vs"]),
            "U_definition": "data-level VUCA composite over " + ", ".join(cfg["inner_weights"]["vuca"]),
            "normalization": "min-max against weights.yaml reference_ranges; "
                             "volume and velocity on log10 scale; floor 0.02",
            "inner_weights": cfg["inner_weights"],
        },
    }
    return result

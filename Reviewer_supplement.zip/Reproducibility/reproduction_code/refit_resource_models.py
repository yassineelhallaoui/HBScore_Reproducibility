"""Refit the locked resource models using the original family split."""
import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import yaml


def main():
    root=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser()
    p.add_argument('--package',type=Path,default=root);p.add_argument('--out',type=Path,default=root/'reproduced/refit')
    args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str(args.package/'research/code'))
    import sklearn
    if np.__version__!='2.5.1' or sklearn.__version__!='1.9.0':
        raise SystemExit('Exact refit needs the historical NumPy 2.5.1 / scikit-learn 1.9.0 environment recorded in research/environment/requirements-lock.txt. Offline metric replay uses the separate replay environment.')
    from routeb.validation import MODEL_SPECS,grouped_holdout_predictions,prediction_metrics
    frozen=args.package/'research/outputs/final_frozen';frame=pd.read_csv(frozen/'benchmark_trials.csv')
    config=yaml.safe_load((args.package/'research/config/experiment.yaml').read_text())['validation']
    lock=yaml.safe_load((args.package/'research/config/final_model_lock.yaml').read_text())
    holdout=frame.family.isin(config['final_holdout_families']);train=frame.loc[~holdout];test=frame.loc[holdout]
    assert train.family.nunique()==14 and len(train)==4320 and len(test)==864
    expected=pd.read_csv(frozen/'final_holdout_locked_metrics.csv');results=[];predictions=[]
    for target in ['wall_time_seconds','p95_latency_seconds','peak_rss_bytes']:
        model=lock['selected_models'][target];assert model=='physical_demand'
        prediction=grouped_holdout_predictions(train,test,target,model_specs={model:MODEL_SPECS[model]},
                                               alphas=config['ridge_alphas'],inner_folds=config['inner_folds'])
        metric=prediction_metrics(prediction);reference=expected.loc[expected.target.eq(target)].iloc[0]
        for field in ['mae','r2','log_r2','interval_coverage']:
            np.testing.assert_allclose(metric.iloc[0][field],reference[field],rtol=1e-6,atol=1e-8)
        results.append(metric);predictions.append(prediction);print('Refit matches:',target,flush=True)
    pd.concat(results).to_csv(args.out/'refit_metrics.csv',index=False)
    pd.concat(predictions).to_csv(args.out/'refit_predictions.csv',index=False)
    (args.out/'refit_check.json').write_text(json.dumps({'frozen_comparison':'pass','targets':3,'development_conditions':4320,'holdout_conditions':864,'new_independent_validation':False},indent=2))


if __name__=='__main__':main()

"""Reproduce the solution diagram and recorded logical byte-throughput figure."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numpy as np
import pandas as pd


def throughput_records(frame):
    """Use logical input bytes and elapsed medians from each recorded condition."""
    columns=['family','source_id','variant_id','workload','bytes_read','wall_time_seconds','n_measured_repetitions']
    result=frame[columns].copy()
    if result[columns].isna().any().any():
        raise ValueError('Incomplete throughput records')
    if (result.bytes_read<0).any() or (result.wall_time_seconds<=0).any():
        raise ValueError('Invalid byte quantity or elapsed time')
    if not np.isfinite(result[['bytes_read','wall_time_seconds']].to_numpy()).all():
        raise ValueError('Non-finite throughput input')
    result['logical_input_bytes_per_second']=result.bytes_read/result.wall_time_seconds
    return result


def diagram(out):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42})
    fig,ax=plt.subplots(figsize=(7,4.8));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    ax.text(.5,.97,'HBScore: three core infrastructure outputs',ha='center',va='top',weight='bold',fontsize=11)
    for x,title,body in [(.015,'Physical demand','Workload features\nResource estimates'),
                         (.35,'Operational friction','Data quality and meaning\nRelationships and review items'),
                         (.685,'Capacity ratios','Local service envelope\nCoverage and component status')]:
        ax.add_patch(FancyBboxPatch((x,.57),.30,.25,boxstyle='round,pad=.008',facecolor='#e8f2f1',edgecolor='#347d79'))
        ax.text(x+.15,.75,title,ha='center',weight='bold',fontsize=9)
        ax.text(x+.15,.65,body,ha='center',va='center',fontsize=7.3,linespacing=1.7)
        ax.annotate('',xy=(.5,.45),xytext=(x+.15,.56),arrowprops={'arrowstyle':'->','color':'#347d79'})
    ax.text(.5,.40,'Business decision and recorded intervention',ha='center',weight='bold',fontsize=10)
    ax.add_patch(FancyBboxPatch((.12,.07),.76,.22,boxstyle='round,pad=.008',facecolor='#faf0da',edgecolor='#b9893c',linestyle='--'))
    ax.text(.5,.235,'External business panel',ha='center',weight='bold',fontsize=10)
    ax.text(.5,.145,'Raw byte volume + byte throughput + allocated costs\nMatched service, accepted unit and observation period',ha='center',va='center',fontsize=8,linespacing=1.8)
    ax.annotate('',xy=(.5,.30),xytext=(.5,.37),arrowprops={'arrowstyle':'<->','color':'#b9893c'})
    for ext in ['png','pdf']:fig.savefig(out/('Figure_1_three_output_business_solution.'+ext),dpi=600,bbox_inches='tight',facecolor='white')
    plt.close(fig)


def main():
    p=argparse.ArgumentParser()
    root=Path(__file__).resolve().parents[1]
    p.add_argument('--package',type=Path,default=root)
    p.add_argument('--results',type=Path,default=root/'reproduced')
    p.add_argument('--out',type=Path,default=root/'reproduced/Figures')
    args=p.parse_args();args.results.mkdir(parents=True,exist_ok=True);args.out.mkdir(parents=True,exist_ok=True)
    source=args.package/'research/outputs/final_frozen/benchmark_trials.csv'
    frame=pd.read_csv(source);records=throughput_records(frame)
    records.to_csv(args.results/'byte_throughput_by_condition.csv',index=False)
    rows=[]
    for workload,group in records.groupby('workload',sort=True):
        q=group.logical_input_bytes_per_second.quantile([.25,.5,.75])
        rows.append({'workload':workload,'conditions':len(group),'p25_bytes_per_second':q.loc[.25],
                     'median_bytes_per_second':q.loc[.5],'p75_bytes_per_second':q.loc[.75]})
    summary=pd.DataFrame(rows);summary.to_csv(args.results/'byte_throughput_summary.csv',index=False)
    metadata={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
              'conditions':len(records),'measured_repetitions':int(records.n_measured_repetitions.sum()),
              'definition':'recorded logical bytes_read / recorded median wall_time_seconds per condition',
              'unit':'bytes/second','external_to_three_core_outputs':True,
              'physical_device_io_measured':False,'financial_cost_records_available':False}
    (args.results/'byte_throughput_provenance.json').write_text(json.dumps(metadata,indent=2))
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42})
    fig,ax=plt.subplots(figsize=(6.7,3.8))
    labels=summary.workload.tolist()
    ax.boxplot([records.loc[records.workload.eq(w),'logical_input_bytes_per_second']/1e6 for w in labels],
               tick_labels=labels,showfliers=True,patch_artist=True,
               boxprops={'facecolor':'#e8f2f1','edgecolor':'#347d79'},medianprops={'color':'#19343b'})
    ax.set_yscale('log');ax.set_ylabel('Logical input throughput (decimal MB/s)')
    ax.set_xlabel('Recorded workload');ax.tick_params(axis='x',labelrotation=25)
    ax.grid(axis='y',alpha=.15);fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(args.out/('Figure_2_recorded_byte_throughput.'+ext),dpi=600,bbox_inches='tight',facecolor='white')
    plt.close(fig);diagram(args.out)
    print(json.dumps(metadata,indent=2))


if __name__=='__main__':main()

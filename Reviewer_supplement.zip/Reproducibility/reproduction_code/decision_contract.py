"""HBScore demand-to-capacity checks."""
import math

CONTRACT_VERSION = "1.0.0"


def decision_card(demand, capacity, required, warning=0.70):
    """Compare required components; missing limits remain unknown."""
    if not required or len(set(required)) != len(required):
        raise ValueError("Declare a nonempty set of distinct required components")
    if not 0 < warning < 1:
        raise ValueError("Warning threshold must lie between zero and one")
    ratios, unknown = {}, []
    for key in required:
        d, c = demand.get(key), capacity.get(key)
        if d is None or c is None:
            unknown.append(key)
            continue
        if d["unit"] != c["unit"]:
            raise ValueError(f"Incompatible units for {key}")
        dv, cv = float(d["value"]), float(c["value"])
        if not math.isfinite(dv) or not math.isfinite(cv) or dv < 0 or cv <= 0:
            raise ValueError(f"Invalid physical quantity for {key}")
        ratios[key] = dv / cv
    rho = max(ratios.values()) if ratios else None
    binding = sorted(k for k, v in ratios.items() if math.isclose(v, rho))
    if rho is not None and rho >= 1:
        status = "breach"
    elif unknown:
        status = "incomplete"
    elif rho >= warning:
        status = "warning"
    else:
        status = "within_declared_envelope"
    return {"contract_version": CONTRACT_VERSION, "ratios": ratios,
            "rho_observed": rho, "binding_among_measured": binding,
            "unmeasured_required": unknown, "coverage": len(ratios)/len(required),
            "status": status, "warning_threshold": warning}


def illustrative_cases():
    """Exact scalar collision, chosen analytically; not benchmark observations."""
    cases = []
    for name, d, r, physical in [
        ("A", 0.8, 0.1, {"storage": 80, "compute": 20}),
        ("B", 0.5, 0.6228571428571429, {"storage": 20, "compute": 80}),
    ]:
        demand = {k: {"value": v, "unit": "declared_units"} for k, v in physical.items()}
        capacity = {k: {"value": 100, "unit": "declared_units"} for k in physical}
        cases.append({"case": name, "kind": "analytical_illustration",
                      "demand_summary": d, "friction_summary": r,
                      "legacy_scalar": .6*d + .3*r + .1*d*r,
                      "card": decision_card(demand, capacity, ["storage", "compute"])})
    return cases

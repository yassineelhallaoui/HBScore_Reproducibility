"""Check consequential decision errors, not formatting or implementation details."""
import unittest
from decision_contract import decision_card, illustrative_cases


def q(v, unit="bytes"):
    return {"value": v, "unit": unit}


class ContractTests(unittest.TestCase):
    def test_missing_component_does_not_clear_estate(self):
        card = decision_card({"s": q(1)}, {"s": q(100)}, ["s", "network"])
        self.assertEqual(card["status"], "incomplete")
        self.assertEqual(card["coverage"], .5)

    def test_known_breach_survives_missing_component(self):
        card = decision_card({"s": q(101)}, {"s": q(100)}, ["s", "network"])
        self.assertEqual(card["status"], "breach")
        self.assertEqual(card["unmeasured_required"], ["network"])

    def test_unit_mismatch_and_invalid_limits_are_rejected(self):
        for d, c in [(q(1), q(1, "seconds")), (q(1), q(0)),
                     (q(-1), q(10)), (q(float("nan")), q(10))]:
            with self.assertRaises(ValueError):
                decision_card({"s": d}, {"s": c}, ["s"])

    def test_exact_boundary_and_ties(self):
        card = decision_card({"s": q(1), "c": q(2)},
                             {"s": q(1), "c": q(2)}, ["s", "c"])
        self.assertEqual(card["status"], "breach")
        self.assertEqual(card["binding_among_measured"], ["c", "s"])

    def test_scalar_collision_changes_action(self):
        a, b = illustrative_cases()
        self.assertAlmostEqual(a["legacy_scalar"], b["legacy_scalar"])
        self.assertNotEqual(a["card"]["binding_among_measured"],
                            b["card"]["binding_among_measured"])

    def test_unmeasured_entire_envelope(self):
        card = decision_card({}, {}, ["network"])
        self.assertIsNone(card["rho_observed"])
        self.assertEqual(card["status"], "incomplete")


if __name__ == "__main__":
    unittest.main()

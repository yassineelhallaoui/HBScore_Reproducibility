"""Recompute the three resource-prediction results from frozen holdout records."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

TARGETS={"wall_time_seconds":"Processing time", "p95_latency_seconds":"p95 latency", "peak_rss_bytes":"Peak resident memory"}


def r_squared(observed,predicted):
    denominator=np.square(observed-observed.mean()).sum()
    if denominator<=0:
        raise ValueError('R-squared requires variation in the observed outcome')
    return float(1-np.square(observed-predicted).sum()/denominator)


def main():
    root=Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser()
    p.add_argument('--package',type=Path,default=root)
    p.add_argument('--out',type=Path,default=root/'reproduced')
    args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    frozen=args.package/'research/outputs/final_frozen'
    predictions=pd.read_csv(frozen/'final_holdout_predictions.csv')
    locked=pd.read_csv(frozen/'final_holdout_locked_metrics.csv')
    manifest=json.loads((frozen/'validation_manifest.json').read_text())
    expected_families=set(manifest['final_holdout_families'])
    rows=[]
    for target,label in TARGETS.items():
        metric=locked.loc[locked.target.eq(target)]
        if len(metric)!=1:raise ValueError('Expected one locked primary model per target')
        metric=metric.iloc[0]
        subset=predictions.loc[predictions.target.eq(target)&predictions.model.eq(metric.model)].copy()
        if not subset.locked_primary.all() or not subset.evaluation.eq('final_holdout').all():
            raise ValueError('Only locked final-holdout predictions are eligible')
        if len(subset)!=864 or subset.row_index.nunique()!=864 or set(subset.held_out_family)!=expected_families:
            raise ValueError('Unexpected final-holdout coverage')
        observed=subset.observed.to_numpy(float);predicted=subset.predicted.to_numpy(float)
        if not np.isfinite(np.r_[observed,predicted]).all() or (observed<0).any() or (predicted<0).any():
            raise ValueError('Invalid resource outcome')
        original_r2=r_squared(observed,predicted)
        log_r2=r_squared(np.log1p(observed),np.log1p(predicted))
        coverage=float(((observed>=subset.interval_lower)&(observed<=subset.interval_upper)).mean())
        np.testing.assert_allclose([original_r2,log_r2,coverage],[metric.r2,metric.log_r2,metric.interval_coverage],rtol=1e-10,atol=1e-12)
        rows.append({'outcome':label,'target':target,'model':metric.model,'conditions':len(subset),
                     'families':len(expected_families),'log_r2':log_r2,'original_r2':original_r2,
                     'nominal_interval_coverage':.90,'empirical_interval_coverage':coverage})
    pd.DataFrame(rows).to_csv(args.out/'validation_evidence.csv',index=False)
    report={'scope':'Proof of concept for the three tested physical-resource predictions in the recorded environment',
            'new_experiment':False,'log_transform':'natural log(1 + outcome)',
            'held_out_families':sorted(expected_families),'conditions_per_target':864,
            'frozen_metric_comparison':'pass','records':rows,
            'source_sha256':{name:hashlib.sha256((frozen/name).read_bytes()).hexdigest() for name in
                             ['final_holdout_predictions.csv','final_holdout_locked_metrics.csv','validation_manifest.json']}}
    (args.out/'validation_evidence.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'validation_targets':len(rows),'conditions_per_target':864,'frozen_metric_comparison':'pass'},indent=2))


if __name__=='__main__':main()

"""Sampling and rank statistics from the completed sensitivity audit."""
import math
import numpy as np

EPS=0.02
GROUPS=("five_vs","vuca")
RANGE_MAP={"volume":("volume_bytes",True),"velocity":("events_per_day",True),
           "variety":("variety_index",False),"volatility":("growth_cv",False),
           "complexity":("complexity_index",False),"ambiguity":("ambiguity_raw",False)}

def raw_indicators(profiles):

    result = {key: [] for key in RANGE_MAP}
    for p in profiles:
        fv, vu = p["five_vs"], p["vuca"]
        vel = fv["velocity"]
        events = vel.get("est_events_per_day") or 0.0
        med = vel.get("median_interval_s")
        if not events and med and med >= 1.0:
            events = 86400.0 / med
        result["volume"].append(fv["volume"]["total_bytes"])
        result["velocity"].append(events)
        result["variety"].append(fv["variety"]["dtype_entropy"]
                                 + fv["variety"]["format_entropy"]
                                 + fv["variety"]["n_modalities"] - 1)
        result["volatility"].append(vu["volatility"]["growth_cv"])
        result["complexity"].append(vu["complexity"]["density"] * 10
                                    + vu["complexity"]["centrality_concentration"]
                                    + math.log10(max(vu["complexity"]["n_nodes"], 1)) / 4)
        result["ambiguity"].append(vu["ambiguity"]["ambiguity_raw"])
    return result

def rank_scores(scores):

    order = np.argsort(-scores, axis=1, kind="stable")
    ranks = np.empty_like(order, dtype=np.uint16)
    np.put_along_axis(ranks, order, np.arange(1, scores.shape[1] + 1)[None, :], axis=1)
    return ranks

class Sampler:
    def __init__(self, profiles, cfg, original):
        self.profiles, self.cfg = profiles, cfg
        self.names = [p["dataset"] for p in profiles]
        self.keys = [k for g in GROUPS for k in cfg["inner_weights"][g]]
        self.outer_keys = list(cfg["outer_weights"])
        self.weight_keys = [g + "." + k for g in GROUPS for k in cfg["inner_weights"][g]]
        self.weight_keys += ["outer." + k for k in self.outer_keys]
        self.base_weights = np.array([cfg["inner_weights"][g][k]
                                      for g in GROUPS for k in cfg["inner_weights"][g]]
                                     + [cfg["outer_weights"][k] for k in self.outer_keys])
        self.indicators = np.array([[original.indicator_values(p, cfg)[k]
                                     for k in self.keys] for p in profiles])
        self.raw = raw_indicators(profiles)
        self.range_keys = list(cfg["reference_ranges"])
        self.endpoints = np.array([[cfg["reference_ranges"][k][end] for end in ("lo", "hi")]
                                   for k in self.range_keys], dtype=float)
        self.base_scores = np.array([original.compute(p, cfg)["hb_score"] for p in profiles])
        self.base_ranks = rank_scores(self.base_scores[None, :])[0]
        self.n_five = len(cfg["inner_weights"]["five_vs"])

    def batch(self, rng, count, perturb, perturb_ranges):


        nw = len(self.base_weights)
        nr = self.endpoints.size if perturb_ranges else 0
        uniforms = rng.random((count, nw + nr))
        weights = self.base_weights * ((1 - perturb) + 2 * perturb * uniforms[:, :nw])
        endpoints = np.broadcast_to(self.endpoints, (count,) + self.endpoints.shape).copy()
        if perturb_ranges:
            endpoints *= 10 ** ((-perturb_ranges + 2 * perturb_ranges * uniforms[:, nw:])
                               .reshape(count, -1, 2))
        ind = np.broadcast_to(self.indicators, (count,) + self.indicators.shape).copy()
        if perturb_ranges:
            for key, (range_key, logarithmic) in RANGE_MAP.items():
                ri = self.range_keys.index(range_key)
                lo, hi = endpoints[:, ri, 0].copy(), endpoints[:, ri, 1].copy()
                raw = self.raw[key]
                missing = np.array([v is None for v in raw])
                if logarithmic:
                    x = np.array([math.log10(max(v, 1e-9)) if v is not None else 0 for v in raw])

                    lo = np.array([math.log10(max(v, 1e-9)) for v in lo])
                    hi = np.array([math.log10(max(v, 1e-9)) for v in hi])
                else:
                    x = np.array([v if v is not None else 0 for v in raw])
                valid = hi > lo
                transformed = (x[None, :] - lo[:, None]) / np.where(valid, hi - lo, 1)[:, None]
                transformed = np.clip(transformed, EPS, 1)
                transformed[~valid, :] = EPS
                transformed[:, missing] = EPS
                ind[:, :, self.keys.index(key)] = transformed
        a = self.n_five
        b = len(self.keys)
        wf = weights[:, :a] / weights[:, :a].sum(axis=1, keepdims=True)
        wu = weights[:, a:b] / weights[:, a:b].sum(axis=1, keepdims=True)
        f = np.exp((np.log(ind[:, :, :a]) * wf[:, None, :]).sum(axis=2))
        u = np.exp((np.log(ind[:, :, a:b]) * wu[:, None, :]).sum(axis=2))
        outer = weights[:, b:] / weights[:, b:].sum(axis=1, keepdims=True)
        alpha, beta, gamma = [outer[:, self.outer_keys.index(k), None]
                              for k in ("alpha", "beta", "gamma")]
        values = alpha * f + beta * u + gamma * f * u

        scores = np.fromiter((round(float(v), 4) for v in values.flat), float,
                             count=values.size).reshape(values.shape)
        return rank_scores(scores), weights, endpoints, scores

def summary(sampler, ranks, label, perturb, ranges, seed):
    n = len(ranks)
    p5, p95 = np.percentile(ranks, [5, 95], axis=0)
    legacy_low, legacy_high = p5.astype(int), p95.astype(int)
    rows = []
    for i, name in enumerate(sampler.names):
        same = np.mean(ranks[:, i] == sampler.base_ranks[i])
        rows.append({"experiment": label, "iterations": n, "perturbation": perturb,
                     "perturbation_ranges": ranges, "seed": seed, "dataset": name,
                     "industry": sampler.profiles[i]["industry"],
                     "base_rank": int(sampler.base_ranks[i]),
                     "rank_p5": int(legacy_low[i]), "rank_p95": int(legacy_high[i]),
                     "rank_stable": bool(legacy_low[i] == legacy_high[i]),
                     "rank_p5_untruncated": float(p5[i]), "rank_p95_untruncated": float(p95[i]),
                     "mean_rank": float(ranks[:, i].mean()),
                     "min_rank": int(ranks[:, i].min()), "max_rank": int(ranks[:, i].max()),
                     "probability_base_rank": float(same),
                     "probability_base_rank_mc_se": float(np.sqrt(same * (1 - same) / n)),
                     "probability_first": float(np.mean(ranks[:, i] == 1))})
    base_center = sampler.base_ranks.astype(float) - np.mean(sampler.base_ranks)

    rho = ((ranks.astype(float) - ranks.mean(axis=1, keepdims=True)) * base_center).sum(axis=1)
    rho /= np.sum(base_center ** 2)
    overall = {"experiment": label, "iterations": n, "perturbation": perturb,
               "perturbation_ranges": ranges, "seed": seed,
               "mean_rank_band": float(np.mean(legacy_high - legacy_low)),
               "stable_datasets": int(np.sum(legacy_low == legacy_high)),
               "mean_spearman_to_base": float(np.mean(rho)),
               "mean_absolute_rank_change": float(np.abs(ranks.astype(float) - sampler.base_ranks).mean()),
               "base_leader_probability_first": float(np.mean(ranks[:, np.argmin(sampler.base_ranks)] == 1))}
    return rows, overall

"""Replay the survey statistics and completed sensitivity audit."""
import argparse
import json
import re
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import yaml

import exploratory_scoring
from sensitivity_engine import Sampler,summary

SECTORS={'finance':'Finance','healthcare':'Healthcare','manufacturing':'Industry/IoT'}


def survey_statistics(source,out):
    data=json.loads((source/'survey_aggregates.json').read_text())
    for sector in data['sectors']:
        file=source/'survey_exports'/sector['raw_source_file']
        frame=pd.read_csv(file);mapping={}
        for column in frame:
            match=re.match(r'\s*([A-F]\d{1,2})[.\s]',str(column))
            if match:mapping[match.group(1)]=column
        assert len(frame)==sector['n']
        for block in sector['blocks'].values():
            values=frame[[mapping[item] for item in block['items']]].apply(pd.to_numeric,errors='raise').dropna()
            covariance=values.cov().to_numpy()
            np.testing.assert_allclose(covariance,np.array(block['covariance']),rtol=1e-12,atol=1e-12)
            block['covariance']=covariance.tolist();block['n']=len(values)
        ranking=sector['weight_ranking']
        values=frame[[mapping[item] for item in ranking['items']]].apply(pd.to_numeric,errors='raise').dropna()
        sums=values.rank(axis=1,ascending=False).sum().to_numpy()
        ties=int(sum(sum(int(size)**3-int(size) for size in row.value_counts().values if size>1) for _,row in values.iterrows()))
        np.testing.assert_array_equal(sums,ranking['rank_sums']);assert ties==ranking['tie_correction_sum']
        ranking.update(rank_sums=sums.tolist(),tie_correction_sum=ties,n=len(values))
    alphas=[];agreement=[]
    for sector in data['sectors']:
        for block,value in sector['blocks'].items():
            covariance=np.array(value['covariance'],dtype=float);k=len(covariance)
            alpha=k/(k-1)*(1-np.trace(covariance)/covariance.sum())
            alphas.append({'sector':sector['sector'],'block':block,'n':value['n'],'alpha':alpha})
        rank=sector['weight_ranking'];sums=np.array(rank['rank_sums']);n=rank['n'];k=len(sums)
        squared=float(np.square(sums-sums.mean()).sum())
        denominator=n*n*(k**3-k)
        uncorrected=12*squared/denominator
        corrected=12*squared/(denominator-n*rank['tie_correction_sum'])
        assert round(uncorrected,3)==sector['recorded_kendall_w']
        agreement.append({'sector':sector['sector'],'n':n,'items':k,'recorded_w':uncorrected,'tie_corrected_w':corrected})
    alpha=pd.DataFrame(alphas);w=pd.DataFrame(agreement)
    alpha.to_csv(out/'survey_alpha.csv',index=False);w.to_csv(out/'survey_concordance.csv',index=False)
    for sector in data['sectors']:
        expected=sector['recorded_reliability'];subset=alpha.loc[alpha.sector.eq(sector['sector'])].set_index('block')
        assert round(subset.loc['Environmental VUCA (12 items)','alpha'],3)==expected['environmental_vuca_total']
        for name in ['volatility','uncertainty','complexity','ambiguity']:
            assert round(subset.loc[name.capitalize()+' (3 items)','alpha'],3)==expected['environmental_vuca_subscales'][name]
        assert round(subset.loc['Estate perception (6 items)','alpha'],3)==expected['data_estate_perception']
        assert round(subset.loc['Five Vs perception (5 items)','alpha'],3)==expected['five_vs_perception']
    return alpha,w


def rerun_audit(source,checkpoints,out):
    profiles=[json.loads(p.read_text()) for p in sorted((source/'profiles').glob('*.json'))]
    cfg=yaml.safe_load((source/'sensitivity_weights.yaml').read_text());sampler=Sampler(profiles,cfg,exploratory_scoring)
    outputs=[]
    configs=checkpoints[['experiment','perturbation','perturbation_ranges','seed']].drop_duplicates()
    configs=configs.loc[~configs.experiment.isin(['experiment_1_10000','original_2000_reproduction'])]
    for _,config in configs.iterrows():
        selected=checkpoints.loc[checkpoints.experiment.eq(config.experiment)].sort_values('iterations')
        rng=np.random.default_rng(int(config.seed));maximum=int(selected.iterations.max())
        ranks=np.empty((maximum,len(profiles)),dtype=np.uint16);done=0
        for _,expected in selected.iterrows():
            stop=int(expected.iterations)
            while done<stop:
                count=min(2000,stop-done)
                batch,_,_,_=sampler.batch(rng,count,float(config.perturbation),float(config.perturbation_ranges))
                ranks[done:done+count]=batch;done+=count
            _,actual=summary(sampler,ranks[:stop],config.experiment,float(config.perturbation),float(config.perturbation_ranges),int(config.seed))
            for key in ['mean_rank_band','stable_datasets','mean_spearman_to_base','mean_absolute_rank_change','base_leader_probability_first']:
                np.testing.assert_allclose(actual[key],expected[key],rtol=1e-11,atol=1e-12)
            outputs.append(actual)
        print('Sensitivity replay matches:',config.experiment,maximum,'draws',flush=True)
    pd.DataFrame(outputs).to_csv(out/'monte_carlo_resimulation.csv',index=False)


def figures(alpha,w,checkpoints,out):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42})
    def save(fig,stem):
        for ext in ['png','pdf']:fig.savefig(out/(stem+'.'+ext),dpi=600,bbox_inches='tight',facecolor='white')
        plt.close(fig)
    blocks=alpha.block.drop_duplicates().tolist();labels=['Environmental VUCA (12)','Volatility (3)','Uncertainty (3)','Complexity (3)','Ambiguity (3)','Estate perception (6)','Five Vs perception (5)']
    fig,(a,b)=plt.subplots(2,1,figsize=(7,6),gridspec_kw={'height_ratios':[2.6,1]},constrained_layout=True)
    colors=['#347d79','#4a6fa5','#b9893c'];y=np.arange(len(blocks))
    for i,sector in enumerate(SECTORS):
        values=alpha.loc[alpha.sector.eq(sector)].set_index('block').loc[blocks,'alpha']
        a.barh(y+(i-1)*.22,values,height=.20,color=colors[i],label=SECTORS[sector])
    a.set_yticks(y,labels);a.invert_yaxis();a.set_xlim(0,1);a.axvline(.70,color='#666',ls='--',lw=.8)
    a.set_xlabel('Cronbach alpha; dashed line marks the 0.70 reference');a.legend(ncol=3,loc='lower right',fontsize=7)
    a.set_title('(a) Internal consistency by survey block',loc='left')
    for i,row in w.iterrows():
        b.scatter(row.recorded_w,i,marker='o',facecolor='white',edgecolor=colors[i],s=35)
        b.scatter(row.tie_corrected_w,i,marker='s',color=colors[i],s=30)
        b.plot([row.recorded_w,row.tie_corrected_w],[i,i],color=colors[i],lw=.8)
    b.set_yticks(range(3),list(SECTORS.values()));b.set_xlim(0,1);b.set_xlabel('Kendall W: open circle recorded; filled square tie-corrected')
    b.set_title('(b) Agreement on the nine importance rankings',loc='left');b.grid(axis='x',alpha=.15)
    save(fig,'Figure_4_survey_measurement_audit')
    main=checkpoints.loc[checkpoints.experiment.eq('experiment_2_100000')].sort_values('iterations')
    fig,axes=plt.subplots(1,2,figsize=(7,3.2),constrained_layout=True)
    axes[0].plot(main.iterations,main.mean_rank_band,'o-',color=colors[0]);axes[0].set(xscale='log',xlabel='Draws',ylabel='Mean rank-band width',ylim=(0,5),title='(a) Rank-band convergence')
    probability=main.base_leader_probability_first;se=np.sqrt(probability*(1-probability)/main.iterations)
    axes[1].errorbar(main.iterations,100*probability,yerr=100*1.96*se,fmt='o-',color=colors[1],capsize=3)
    axes[1].set(xscale='log',xlabel='Draws',ylabel='Original leader remains first (%)',ylim=(45,60),title='(b) Leader probability')
    for ax in axes:ax.grid(alpha=.15)
    save(fig,'Figure_5_monte_carlo_convergence')
    grid=checkpoints.loc[checkpoints.experiment.str.startswith('experiment_3_grid')&checkpoints.iterations.eq(100000)]
    matrix=grid.pivot(index='perturbation',columns='perturbation_ranges',values='mean_rank_band').sort_index()
    fig,ax=plt.subplots(figsize=(6.6,3.5),constrained_layout=True);im=ax.imshow(matrix.to_numpy(),cmap='YlGnBu',vmin=0,vmax=9,aspect='auto')
    ax.set_xticks(range(len(matrix.columns)),[f'±{v:g}' for v in matrix.columns]);ax.set_yticks(range(len(matrix)),[f'±{100*v:.0f}%' for v in matrix.index])
    ax.set(xlabel='Reference-range endpoint perturbation (log10 units)',ylabel='Weight perturbation',title='Post-test sensitivity grid: 100,000 draws per setting')
    for i in range(len(matrix)):
        for k in range(len(matrix.columns)):ax.text(k,i,f'{matrix.iloc[i,k]:.2f}',ha='center',va='center',color='white' if matrix.iloc[i,k]>5 else '#19343b')
    fig.colorbar(im,ax=ax,label='Mean rank-band width');save(fig,'Figure_6_post_test_sensitivity_grid')


def main():
    root=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser()
    p.add_argument('--package',type=Path,default=root);p.add_argument('--out',type=Path,default=root/'reproduced')
    p.add_argument('--figures',type=Path);p.add_argument('--rerun',action='store_true')
    args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    source=args.package/'supporting_measurements';alpha,w=survey_statistics(source,args.out)
    checkpoints=pd.read_csv(source/'monte_carlo_checkpoints.csv')
    main=checkpoints.loc[checkpoints.experiment.eq('experiment_2_100000')].sort_values('iterations')
    main.to_csv(args.out/'monte_carlo_convergence.csv',index=False)
    grid=checkpoints.loc[checkpoints.experiment.str.startswith('experiment_3_grid')&checkpoints.iterations.eq(100000)]
    assert len(grid)==12;grid.to_csv(args.out/'post_test_grid.csv',index=False)
    if args.rerun:rerun_audit(source,checkpoints,args.out)
    target=args.figures or args.out/'Figures';target.mkdir(parents=True,exist_ok=True);figures(alpha,w,checkpoints,target)
    report={'respondents':81,'sector_n':dict(zip(w.sector,w.n)),'survey_sufficient_statistics_recomputed':True,'survey_exports_checked':True,
            'kendall_tie_correction_reported_separately':True,'sensitivity_cohort':51,'post_test_grid_settings':12,
            'simulation_rerun':args.rerun,'rank_audit_is_not_final_three_output_validation':True}
    (args.out/'survey_sensitivity_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))


if __name__=='__main__':main()

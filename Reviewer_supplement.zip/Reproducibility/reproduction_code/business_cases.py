"""Illustrative business cases; these are not provider observations."""
from business_metrics import external_metrics
from decision_contract import decision_card


def cases():
    names=["storage","ingest","compute","io","memory","network","concurrency"]
    units=["bytes","events/second","cells/window","bytes/window","bytes","bytes/window","workers"]
    base_demand=[50e9,2000,8e6,1.2e9,6e9,.4e9,8]
    base_capacity=[100e9,4000,10e6,2.4e9,12e9,1e9,16]
    scope={"service_id":"illustrative_service","unit":"accepted transaction",
           "start":"2026-01-01T00:00:00+00:00","end":"2026-01-01T01:00:00+00:00"}
    cost_scope={**scope,"allocation_rule":"allocated service cost for this hour",
                "cost_basis":"illustrative scenario cost"}
    result=[]
    for name,completed,cost in [("Current configuration",300000,600),
                                ("Additional compute capacity",400000,900),
                                ("Retention and quality work",330000,580)]:
        demand=list(base_demand);capacity=list(base_capacity)
        friction={"quality_debt_rate":.10,"ambiguity_rate":.05,"structural_note":"declared relationships"}
        if name=="Additional compute capacity":capacity[2]=20e6
        if name=="Retention and quality work":
            demand[0]=40e9;demand[2]=6e6;friction["quality_debt_rate"]=.02
        d={k:{"value":v,"unit":u} for k,v,u in zip(names,demand,units)}
        c={k:{"value":v,"unit":u} for k,v,u in zip(names,capacity,units)}
        result.append({"case":name,"basis":"illustrative_scenario",
                       "core_outputs":{"physical_demand":d,"operational_friction":friction,
                                       "component_capacity_ratios":decision_card(d,c,names)},
                       "capacity_profile":{"service_window_seconds":1,"components":c},
                       "external_business_metrics":external_metrics(completed,scope,cost,"USD",cost_scope,basis="scenario")})
    return result

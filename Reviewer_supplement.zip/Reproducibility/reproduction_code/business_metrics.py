"""External productivity and cost metrics for a declared service scope."""
import math
from datetime import datetime

SCOPE_KEYS=("service_id","unit","start","end")


def external_metrics(completed_units, scope, allocated_cost=None, currency=None, cost_scope=None, basis="observed"):
    """Pair completed work with an independently supplied, matching cost scope."""
    if any(not scope.get(k) for k in SCOPE_KEYS):
        raise ValueError("Service, unit and observation window are required")
    start=datetime.fromisoformat(scope["start"].replace("Z","+00:00"))
    end=datetime.fromisoformat(scope["end"].replace("Z","+00:00"))
    if start.tzinfo is None or end.tzinfo is None:
        raise ValueError("Observation times need time zones")
    seconds=(end-start).total_seconds()
    units=float(completed_units)
    if seconds<=0 or not math.isfinite(units) or units<0:
        raise ValueError("Work must be nonnegative and the window positive")
    if basis not in {"observed","scenario"}:
        raise ValueError("Label inputs as observed or scenario")
    result={"scope":dict(scope),"basis":basis,"completed_units":units,
            "window_seconds":seconds,"throughput_units_per_second":units/seconds,
            "throughput_units_per_hour":units/seconds*3600,
            "allocated_cost":None,"currency":None,"cost_per_unit":None,
            "cost_per_1000_units":None,"completed_units_per_currency":None,
            "financial_status":"cost_unavailable"}
    if allocated_cost is None:
        return result
    if cost_scope is None or any(cost_scope.get(k)!=scope[k] for k in SCOPE_KEYS):
        raise ValueError("Cost and activity must refer to the same scope")
    cost=float(allocated_cost)
    if not math.isfinite(cost) or cost<0 or not currency:
        raise ValueError("Cost must be nonnegative and currency specified")
    if not cost_scope.get("allocation_rule") or not cost_scope.get("cost_basis"):
        raise ValueError("Record the allocation rule and cost basis")
    result.update(allocated_cost=cost,currency=currency,cost_scope=dict(cost_scope))
    if units==0:
        result["financial_status"]="no_completed_units"
        return result
    result.update(cost_per_unit=cost/units,cost_per_1000_units=1000*cost/units,
                  completed_units_per_currency=units/cost if cost>0 else None,
                  financial_status="matched_scope")
    return result

# Survey item wording

Item wording is retained from each exported form. The numerical analysis uses the closed B, C, D and E blocks.

## Financial Services

- B1. Market conditions in our sector change rapidly and unpredictably.
- B2. The pace of change around our operations has clearly accelerated over the past two years.
- B3. Sudden disruptions (supply, regulation, demand) frequently force us to change plans.
- B4. It is difficult to predict how our operating environment will look twelve months from now.
- B5. We often lack the information we would need to anticipate important changes.
- B6. The outcomes of our strategic decisions are hard to foresee.
- B7. Decisions in our organization depend on many interconnected factors that are hard to trace.
- B8. Our operations involve a large number of interdependent systems, partners and regulations.
- B9. Understanding cause and effect across our business processes is genuinely difficult.
- B10. The situations we face are often open to several conflicting interpretations.
- B11. Even when data is available, what it means for action is often unclear.
- B12. We regularly face situations that are genuinely new, with no precedent to rely on.
- C1. The volume of data our organization handles grows in sudden, unpredictable bursts.
- C2. Our datasets frequently contain missing, incomplete or inconsistent records.
- C3. Our data landscape involves many interdependent systems and pipelines; a change in one place affects many others.
- C4. The same business entity (customer, product, asset) is often defined differently across our systems.
- C5. Integrating a new data source into our environment typically takes significant effort.
- C6. Disagreements about what a metric or field actually means are common in our organization.
- D1. Our infrastructure comfortably handles the volume of data we generate. (Volume)
- D2. We can process and act on data as fast as it arrives. (Velocity)
- D3. We effectively integrate structured and unstructured data from diverse sources. (Variety)
- D4. The data we use for decisions is accurate, complete and trustworthy. (Veracity)
- D5. Our data investments demonstrably improve business outcomes. (Value)
- E1. Volume - the sheer amount of data
- E2. Velocity - the speed at which data arrives and must be processed
- E3. Variety - the diversity of data types and sources
- E4. Veracity - the quality and trustworthiness of the data
- E5. Value - the expected business relevance of the data
- E6. Volatility - how unpredictably the data grows and changes
- E7. Uncertainty - how incomplete or inconsistent the data is
- E8. Complexity - how interdependent the data sources and systems are
- E9. Ambiguity - how much the meaning of the data is disputed or unclear
- E10. Overall, when judging how demanding a data project is, where would you put the balance between the technical characteristics of the data (the Five Vs) and the turbulence of the data landscape (Volatility, Uncertainty, Complexity, Ambiguity)?

## Healthcare

- B1. Market conditions in our sector change rapidly and unpredictably.
- B2. The pace of change around our operations has clearly accelerated over the past two years.
- B3. Sudden disruptions (supply, regulation, demand) frequently force us to change plans.
- B4. It is difficult to predict how our operating environment will look twelve months from now.
- B5. We often lack the information we would need to anticipate important changes.
- B6. The outcomes of our strategic decisions are hard to foresee.
- B7. Decisions in our organization depend on many interconnected factors that are hard to trace.
- B8. Our operations involve a large number of interdependent systems, partners and regulations.
- B9. Understanding cause and effect across our business processes is genuinely difficult.
- B10. The situations we face are often open to several conflicting interpretations.
- B11. Even when data is available, what it means for action is often unclear.
- B12. We regularly face situations that are genuinely new, with no precedent to rely on.
- C1. The volume of data our organization handles grows in sudden, unpredictable bursts.
- C2. Our datasets frequently contain missing, incomplete or inconsistent records.
- C3. Our data landscape involves many interdependent systems and pipelines; a change in one place affects many others.
- C4. The same business entity (customer, product, asset) is often defined differently across our systems.
- C5. Integrating a new data source into our environment typically takes significant effort.
- C6. Disagreements about what a metric or field actually means are common in our organization.
- D1. Our infrastructure comfortably handles the volume of data we generate. (Volume)
- D2. We can process and act on data as fast as it arrives. (Velocity)
- D3. We effectively integrate structured and unstructured data from diverse sources. (Variety)
- D4. The data we use for decisions is accurate, complete and trustworthy. (Veracity)
- D5. Our data investments demonstrably improve business outcomes. (Value)
- E1. Volume - the sheer amount of data
- E2. Velocity - the speed at which data arrives and must be processed
- E3. Variety - the diversity of data types and sources
- E4. Veracity - the quality and trustworthiness of the data
- E5. Value - the expected business relevance of the data
- E6. Volatility - how unpredictably the data grows and changes
- E7. Uncertainty - how incomplete or inconsistent the data is
- E8. Complexity - how interdependent the data sources and systems are
- E9. Ambiguity - how much the meaning of the data is disputed or unclear
- E10. Overall, when judging how demanding a data project is, where would you put the balance between the technical characteristics of the data (the Five Vs) and the turbulence of the data landscape (Volatility, Uncertainty, Complexity, Ambiguity)?

## Manufacturing

- B1. Market conditions in our sector change rapidly and unpredictably.
- B2. The pace of change around our operations has clearly accelerated over the past two years.
- B3. Sudden disruptions (supply, regulation, demand) frequently force us to change plans.
- B4. It is difficult to predict how our operating environment will look twelve months from now.
- B5. We often lack the information we would need to anticipate important changes.
- B6. The outcomes of our strategic decisions are hard to foresee.
- B7. Decisions in our organization depend on many interconnected factors that are hard to trace.
- B8. Our operations involve a large number of interdependent systems, partners and regulations.
- B9. Understanding cause and effect across our business processes is genuinely difficult.
- B10. The situations we face are often open to several conflicting interpretations.
- B11. Even when data is available, what it means for action is often unclear.
- B12. We regularly face situations that are genuinely new, with no precedent to rely on.
- C1. The volume of data our organization handles grows in sudden, unpredictable bursts.
- C2. Our datasets frequently contain missing, incomplete or inconsistent records.
- C3. Our data landscape involves many interdependent systems and pipelines; a change in one place affects many others.
- C4. The same business entity (customer, product, asset) is often defined differently across our systems.
- C5. Integrating a new data source into our environment typically takes significant effort.
- C6. Disagreements about what a metric or field actually means are common in our organization.
- D1. Our infrastructure comfortably handles the volume of data we generate. (Volume)
- D2. We can process and act on data as fast as it arrives. (Velocity)
- D3. We effectively integrate structured and unstructured data from diverse sources. (Variety)
- D4. The data we use for decisions is accurate, complete and trustworthy. (Veracity)
- D5. Our data investments demonstrably improve business outcomes. (Value)
- E1. Volume - the sheer amount of data
- E2. Velocity - the speed at which data arrives and must be processed
- E3. Variety - the diversity of data types and sources
- E4. Veracity - the quality and trustworthiness of the data
- E5. Value - the expected business relevance of the data
- E6. Volatility - how unpredictably the data grows and changes
- E7. Uncertainty - how incomplete or inconsistent the data is
- E8. Complexity - how interdependent the data sources and systems are
- E9. Ambiguity - how much the meaning of the data is disputed or unclear
- E10. Overall, when judging how demanding a data project is, where would you put the balance between the technical characteristics of the data (the Five Vs) and the turbulence of the data landscape (Volatility, Uncertainty, Complexity, Ambiguity)?

